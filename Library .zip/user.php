<?php
//namespace Blog;
echo "User ";
class User2 {
  private $Name;
  private $Email;
  private $Phone;
  private $password;
    
  public function __construct($Name,$Email,$Phone,$password) {
        
    $this->Name = $Name;
    $this->Email = $Email;
    $this->Phone = $Phone;
    $this->password = $password;
 
}
  
    
public function register() {
  $db = DBL4::getInstance(); 
  $connection = $db->getConnection();   
  $query = "INSERT INTO users (Name,Email,Phone, password) VALUES ('$this->Name','$this->Email','$this->Phone','$this->password')";  
  $stmt = mysqli_query($connection,$query);
  if ($stmt) {
      return true;
  }else return false;
}


public static function login($Name, $password) {
  $db = DBL4::getInstance();
  $connection = $db->getConnection();
  $query = "SELECT * FROM users WHERE Name = '$Name' AND password ='$password'";    
  $stmt = mysqli_query($connection,$query);
  $user = mysqli_fetch_assoc($stmt);

  if ($user) {
    session_start();
    $_SESSION['user_id'] = $user['ID'];
    $_SESSION['Name'] = $user['Name'];
    return true;
  } else {
    return false;
  }
}

public static function loginM($Name, $password) {
  $db = DBL4::getInstance();
  $connection = $db->getConnection();
  $query = "SELECT * FROM managers WHERE Name = '$Name' AND password ='$password'";    
  $stmt = mysqli_query($connection,$query);
  $user = mysqli_fetch_assoc($stmt);
  if ($user) {
    session_start();
    $_SESSION['user_id'] = $user['ID'];
    $_SESSION['Name'] = $user['Name'];
    return true;
  } else {
    return false;
  }
}

public static function logout() {
session_start();
session_destroy();
}
}